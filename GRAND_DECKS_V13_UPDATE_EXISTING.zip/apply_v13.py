#!/usr/bin/env python3
"""Offline, fail-safe source patcher for GRAND DECKS v12 -> v13.

Run from extracted bundle: python apply_v13.py /path/to/grand-decks-tcg
No network, API keys, or deployment performed by this script.
"""
from pathlib import Path
import shutil
import sys

PACKAGE = Path(__file__).resolve().parent

GALLERY = r'''const PRINTINGS_URL = './data/printings.json';
let printingsRequest = null;
async function showCardPrintings(cardId) {
 const panel=document.getElementById('cardPrintingsPanel');
 if(!panel||panel.dataset.cardId!==cardId)return;
 try {
  if(!printingsRequest)printingsRequest=fetchJson(PRINTINGS_URL+'?v='+Date.now()).catch(err=>{printingsRequest=null;throw err;});
  const data=await printingsRequest;
  const current=document.getElementById('cardPrintingsPanel');
  if(!current||current.dataset.cardId!==cardId||!$('#cardDialog').open)return;
  const versions=data?.byCard?.[cardId]||[];
  const labels={base:'一般版',parallel:'平行／異圖',reprint:'復刻版',special:'特別版',unknown:'其他版本'};
  current.innerHTML=`<h3>卡面與印刷版本 · ${versions.length} 款</h3>`+
    (versions.length?'<p class="tiny">同卡號的異圖不增加組牌可用張數；點選卡圖可查看來源圖片。</p><div class="printingsGrid">'+
    versions.map(v=>{
      const title=`${v.printId||cardId} · ${v.locale||''}`;
      const url=String(v.image||'');
      const usable=/^https:\/\/(?:[a-z0-9.-]+)\//i.test(url);
      const picture=usable?`<a target="_blank" rel="noopener noreferrer" href="${safe(url)}"><img loading="lazy" decoding="async" src="${safe(url)}" alt="${safe(title)}" onerror="this.style.display='none'"></a>`:'<span class="printingNoImage">來源暫無圖片</span>';
      return `<div class="printingCard">${picture}<strong>${safe(v.printId||cardId)}</strong><small>${safe(v.locale||'')} · ${safe(labels[v.kind]||v.kind||'其他')} · ${safe(v.rarity||'')}</small></div>`;
    }).join('')+'</div>':'<p>這張卡目前尚無可驗證的印刷版本資料。</p>')+
    '<p class="tiny">版本資料來源：<a href="https://github.com/buhbbl/punk-records" target="_blank" rel="noopener noreferrer">Punk Records</a>、<a href="https://github.com/hotavocado/koala-kollect-data" target="_blank" rel="noopener noreferrer">Koala Kollect（CC BY 4.0）</a>。圖片與卡面權利仍屬原權利人；清單不保證涵蓋尚未公開的版本。</p>';
 } catch(err) {
  const current=document.getElementById('cardPrintingsPanel');
  if(current&&current.dataset.cardId===cardId)current.textContent='印刷版本資料尚未同步或暫時無法載入；既有卡牌與牌組不受影響。';
 }
}
'''

CSS = '''
/* v13 distinct card printings gallery */
#cardPrintingsPanel{margin-top:18px;border-top:1px solid var(--line);padding-top:14px}
#cardPrintingsPanel h3{font-size:16px;margin:0 0 10px}
.printingsGrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(92px,1fr));gap:10px;margin:10px 0}
.printingCard{min-width:0;border:1px solid var(--line);border-radius:9px;background:var(--shell);padding:7px;font-size:11px;overflow:hidden}
.printingCard img{display:block;width:100%;aspect-ratio:5/7;object-fit:contain;border-radius:4px;background:#1a283e}
.printingCard strong,.printingCard small{display:block;overflow-wrap:anywhere;margin-top:5px}
.printingCard small{color:var(--sub)}
.printingNoImage{display:grid;place-items:center;aspect-ratio:5/7;color:var(--sub);border:1px dashed var(--line);text-align:center}
'''


def edit_exact(source, old, new, path):
    count=source.count(old)
    if count != 1:
        raise RuntimeError(f'{path}: expected one exact patch anchor, found {count}: {old[:65]!r}')
    return source.replace(old,new,1)


def prepare(repo):
    changes={}
    def load(path):
        f=repo/path
        if not f.is_file():
            raise RuntimeError(f'Missing GRAND DECKS source: {f}')
        return f.read_text(encoding='utf-8')
    script=load(Path('scripts/run_sync.py'))
    script=edit_exact(script,"('繁中卡牌索引',['sync_cards.py'])","('多語卡牌與全部印刷版本',['sync_full_catalogue.py'])",'run_sync.py')
    script=edit_exact(script,'timeout=230,cwd=ROOT','timeout=600,cwd=ROOT','run_sync.py')
    changes['scripts/run_sync.py']=script
    app=load(Path('public/app.js'))
    app=edit_exact(app,"const SYNC_STATUS_URL = './data/sync-status.json';", "const SYNC_STATUS_URL = './data/sync-status.json';\n"+GALLERY,'app.js')
    app=edit_exact(app,'${effectBlock}${action}<p class="cardDetailFootnote">','${effectBlock}<div id="cardPrintingsPanel" data-card-id="${safe(c.id)}">正在讀取不同卡面版本…</div>${action}<p class="cardDetailFootnote">','app.js')
    app=edit_exact(app,"const dlg=$('#cardDialog');if(!dlg.open)dlg.showModal();", "const dlg=$('#cardDialog');if(!dlg.open)dlg.showModal();\n showCardPrintings(c.id);",'app.js')
    app=edit_exact(app,'· ${a.cardCount||0} 種卡號 · 上次檢查','· ${a.cardCount||0} 種卡號 · ${a.printingCount||0} 個版本紀錄 · 上次檢查','app.js')
    changes['public/app.js']=app
    page=load(Path('public/index.html'))
    if 'v12.0' not in page:
        raise RuntimeError('index.html is not the known v12.0 baseline')
    changes['public/index.html']=page.replace('v12.0','v13.0').replace('?v=12.0','?v=13.0')
    history=load(Path('public/version-history.js'))
    history=edit_exact(history,"  const RELEASES = [", "  const RELEASES = [\n    {version:'13.0', date:'2026-11-22', status:'卡庫擴充', title:'全系列與不同卡面版本', changes:[\n      '以多語官方資料補充繁中未收錄的卡牌與新系列',\n      '將同卡號的平行、異圖、復刻與區域版本個別列出',\n      '保留舊牌組的組牌規則與資料，後續每天自動同步新版本'\n    ]},",'version-history.js')
    changes['public/version-history.js']=history
    sw=load(Path('public/sw.js'))
    sw=edit_exact(sw,"const CACHE='grand-decks-shell-v12-release-effect-1';","const CACHE='grand-decks-shell-v13-printings-1';",'sw.js')
    changes['public/sw.js']=sw
    css=load(Path('public/style.css'))
    changes['public/style.css']=css+'\n'+CSS
    workflow=load(Path('.github/workflows/sync-results.yml'))
    workflow=edit_exact(workflow, "on:\n  workflow_dispatch:", "on:\n  push:\n    branches: [main]\n    paths:\n      - 'scripts/**'\n      - 'public/app.js'\n      - 'public/index.html'\n      - 'public/version-history.js'\n      - '.github/workflows/sync-results.yml'\n  workflow_dispatch:",'sync-results.yml')
    workflow=edit_exact(workflow,'python -m json.tool public/data/cards.json > /dev/null','python -m json.tool public/data/cards.json > /dev/null\n          python -m json.tool public/data/printings.json > /dev/null','sync-results.yml')
    changes['.github/workflows/sync-results.yml']=workflow
    return changes


def main():
    if len(sys.argv)<2:
        raise SystemExit('Usage: python apply_v13.py /path/to/grand-decks-tcg')
    repo=Path(sys.argv[1]).expanduser().resolve()
    if not (repo/'.git').exists():
        raise SystemExit(f'Not a Git repository: {repo}')
    if (repo/'scripts/sync_full_catalogue.py').exists():
        raise SystemExit('The v13 sync file already exists; refusing to overwrite it automatically')
    changes=prepare(repo)  # Check every anchor before modifying any file.
    for path,data in changes.items():
        (repo/path).write_text(data,encoding='utf-8')
    for name in ('sync_full_catalogue.py','test_full_catalogue.py'):
        shutil.copy2(PACKAGE/name, repo/'scripts'/name)
    print('GRAND DECKS v13 source prepared: 9 existing/new files updated. Run tests before committing.')

if __name__ == '__main__':main()
