# GRAND DECKS v13｜完整卡庫與不同卡面版本更新包

適用：`howardjoetw-oss/grand-decks-tcg` 的 v12.0 `main` 版本。

## 更新內容

1. 保留既有組牌格式，一個卡號只計算一張卡牌類別（例如 `OP01-001`）。
2. 新增分開的 `public/data/printings.json`，記錄同一卡號的平行、異圖、復刻、地區語言與稀有度等版本；來源資料有圖時引用原站圖片網址，不下載或鏡像圖檔。
3. 除台灣繁中索引外，新增英文、亞洲英文、香港繁中索引；使用 Koala Kollect 補充日、英、中不同印刷版本。當來源尚未提供繁中名稱，先保留原語言名稱或卡號，而非猜測翻譯。
4. 卡牌詳情頁顯示各版本卡圖與來源資訊；組牌仍維持同卡號最多四張，異圖不會重複計算。
5. 增加資料完整性與數量保護，不因來源暫時失敗而清空既有資料；每日 GitHub Actions 持續更新。

## 檔案說明

- `sync_full_catalogue.py`：新的卡庫同步器，部署後放入 GitHub `scripts/`。
- `test_full_catalogue.py`：離線自動測試，放入 GitHub `scripts/`。
- `apply_v13.py`：以已知 v12 原始碼為基準修改 7 個既有檔案，逐一檢查錨點，不符合會停止。
- `install_v13.sh`：Termux / Linux 一鍵套用、執行測試、建立 commit 並推送 GitHub。需要原有 GitHub 寫入驗證。

## 使用方法

解壓縮後，在已有 Git、Python 和 GitHub 寫入授權的 Termux / Linux 環境中：

```bash
bash install_v13.sh
```

若本機儲存庫不在 `$HOME/grand-decks-tcg`，可加上儲存庫資料夾作為參數：

```bash
bash install_v13.sh /path/to/grand-decks-tcg
```

安裝程式會拒絕覆蓋尚未提交的本機修改。Python 測試失敗或（已安裝 Node 時）JavaScript 語法檢查失敗，都不會推送。`git push` 必須已有寫入權限；沒有授權會明確失敗並保留本機提交，不會嘗試繞過登入。

GitHub 有權限後，`main` 更新會觸發網站既有的自動資料同步及 Cloudflare Pages Git 部署（需原本整合保持正常）。第一次資料同步成功前，版本詳細圖可能顯示「尚未同步」。

## 來源與限制

- Punk Records：<https://github.com/buhbbl/punk-records>
- Koala Kollect Data：<https://github.com/hotavocado/koala-kollect-data>（資料結構與來源紀錄採 CC BY 4.0，需要保留原始出處）
- 官方卡牌與圖片著作權仍屬其原權利人；此功能只引用原站圖片連結。
- 「完整」是指擴充至**所有可由已核准來源取得且有證據的版本**，不代表所有未公開卡、來源未收錄的活動特典或 DON 特殊卡已 100% 收齊。新版應依同步報告的 `cardCount`、`printingCount` 和 `warnings` 判斷實際覆蓋情況。
- 本工具不需要付費 API 或新付費主機，但 GitHub/Cloudflare 免費額度及外部來源條款仍須遵守。

## 本次測試

本機已通過 4 項資料測試（多語合併、異圖去重、歷史資料保留、不連網整合/重複執行），並通過新增瀏覽程式的 Node.js 語法檢查。**尚未通過正式站實際部署、圖片連通性、外部來源即時抓取與所有版本的完整性驗證。**
