#!/usr/bin/env bash
set -euo pipefail
# Optional one-command installer; needs an already-authenticated git push account.
BUNDLE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK="${1:-${HOME}/grand-decks-tcg}"
if ! command -v git >/dev/null || ! command -v python >/dev/null; then
 echo "Requires installed git and python; exiting without changes."; exit 1
fi
if [[ ! -d "${WORK}/.git" ]]; then
 git clone https://github.com/howardjoetw-oss/grand-decks-tcg.git "$WORK"
fi
cd "$WORK"
if [[ -n "$(git status --porcelain)" ]]; then
 echo "Working tree has edits. Refusing to mix changes."; exit 1
fi
git fetch origin main
git switch main
git pull --ff-only origin main
python "$BUNDLE/apply_v13.py" "$WORK"
python -m pip install --disable-pip-version-check beautifulsoup4==4.12.3
python -m unittest discover -s scripts -p 'test_*.py' -v
if command -v node >/dev/null; then
 node --check public/app.js
 node --check public/version-history.js
 node --check public/sw.js
else
 echo 'Node unavailable: skipping the optional JavaScript syntax checks.'
fi
git add scripts/sync_full_catalogue.py scripts/test_full_catalogue.py scripts/run_sync.py public/index.html public/app.js public/style.css public/version-history.js public/sw.js .github/workflows/sync-results.yml
git commit -m 'feat: v13 multilingual card catalogue and regional printings'
echo 'All local tests passed. Pushing to GitHub; requires your existing git authentication.'
git push origin main
echo 'GitHub update sent. GitHub Actions will generate printings.json and publish via Cloudflare Git integration if configured.'
